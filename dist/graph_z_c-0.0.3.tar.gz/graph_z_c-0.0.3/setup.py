from setuptools import find_packages, setup
setup(
    name="graph_z_c",
    version="0.0.3",
    description="Structures to play with graphs",
    packages=['graph_z']    
)